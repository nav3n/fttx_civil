
import React from 'react';
import { ClipOnIcon, OverheadIcon, CivilWorksIcon, InBuildingIcon, TestIcon } from '../components/Icons';
import { WorkflowCategory, InfoItem } from '../types';
import { CITATIONS } from './citations';
import { PoleInstallationDiagram } from '../components/visualizations/PoleInstallationDiagram';
import { BackfillDiagram } from '../components/visualizations/BackfillDiagram';
import { HDDDiagram } from '../components/visualizations/HDDDiagram';
import { MicroTrenchDiagram } from '../components/visualizations/MicroTrenchDiagram';
import { DuctBreakJointDiagram } from '../components/visualizations/DuctBreakJointDiagram';
import { UDMScanningDiagram } from '../components/visualizations/UDMScanningDiagram';

// MAIN WORKFLOW DATA
export const WORKFLOW_DATA: WorkflowCategory[] = [
    {
        id: 'clip-on',
        title: 'Clip-On Fiber Solution',
        icon: <ClipOnIcon />,
        description: 'Workflow for installing fiber optic cables using the Clip-On Solution method in drains or trenches, including the permit application process.',
        sections: [
          {
            title: 'Permit Application Flowchart',
            type: 'flowchart',
            description: 'Process for obtaining a permit for Clip-On Solution projects.',
            citation: { source: CITATIONS.CLIP_ON.id, page: 23 },
            content: [
              { id: 1, title: 'Service Request', responsible: 'Applicant', description: 'Request for service received from user or resident.' },
              { id: 2, title: 'Submit Application', responsible: 'Applicant', description: 'Submit service request proof, development proposal, and supporting documents to the Local/Road Authority (PBT/PBJ).' },
              { id: 3, title: 'Receive & Verify Application', responsible: 'Authority', description: 'PBT/PBJ receives and verifies the application for completeness.' },
              { id: 4, title: 'Technical Review', responsible: 'Authority', description: 'Technical review from related departments to prepare the consideration paper for approval.', duration: '14 Days' },
              { id: 5, title: 'Decision and Recommendation', responsible: 'Authority', description: 'Decision and recommendation on the development proposal at the PBT/PBJ level.' },
              { id: 6, title: 'Notify Decision', responsible: 'Authority', description: 'Communicate the decision to the communication company.' },
              { id: 7, title: 'Apply for Permit', responsible: 'Applicant', description: 'Submit a formal permit application to PBT/PBJ.' },
              { id: 8, title: 'Issue Work Start Approval', responsible: 'Authority', description: 'PBT/PBJ issues the "Surat Kelulusan Mula Kerja" (Work Start Approval Letter).' },
              { id: 9, title: 'Commence On-Site Work', responsible: 'Applicant', description: 'Project work begins on-site.', duration: '14 Days' },
            ],
          },
          {
            title: 'Application Document Requirements',
            type: 'info',
            content: [
              { title: 'Required Documents', details: 'A complete application must include: (1) A cover letter, (2) A softcopy of the proposal with AutoCAD files and site photos in PDF format, (3) Three sets of A1 size site plans, (4) Proof of service request from residents, (5) Insurance copies (Contractor All Risk, Workmen Comp, Public Liabilities), and (6) other documents as required by PBT/PBJ.', citation: { source: CITATIONS.CLIP_ON.id, page: '19-20' } },
            ]
          },
          {
            title: 'Technical & Installation Specifications',
            type: 'info',
            content: [
              { title: 'Allowed Areas', details: 'Installation is permitted in brown field areas for last-mile connections. It is explicitly not to be used for backhaul networks.', citation: { source: CITATIONS.CLIP_ON.id, page: 8 } },
              { title: 'Approval Duration', details: 'Approvals for Clip-On Solution projects are temporary and valid for a maximum of 10 years.', citation: { source: CITATIONS.CLIP_ON.id, page: 8 } },
              { title: 'Cable Specifications', details: 'The maximum allowable circumference for the fiber optic cable is 6mm.', citation: { source: CITATIONS.CLIP_ON.id, page: 9 } },
              { title: 'Installation Spacing', details: 'Clips must be installed to secure the cable at regular intervals of 0.5 meters along the drain or trench wall.', citation: { source: CITATIONS.CLIP_ON.id, page: 9 } },
              { title: 'Installation Depth', details: 'The cable must be installed at a maximum depth of 50mm (2 inches) from the top surface of the drain or trench.', citation: { source: CITATIONS.CLIP_ON.id, page: 10 } },
              { title: 'Installation Restrictions', details: 'Cables are not permitted to cross drain intersections, be installed on drain culverts under roads, or obstruct any maintenance access points.', citation: { source: CITATIONS.CLIP_ON.id, page: 11 } },
              { title: 'Labeling Requirements', details: 'The fiber cable and riser cabinet must be clearly labeled with the name of the service provider for identification.', citation: { source: CITATIONS.CLIP_ON.id, page: 10 } },
            ]
          },
          {
            title: 'Project Monitoring & Fees',
            type: 'info',
            content: [
                { title: 'Monitoring & Reporting', details: 'The communication company is required to conduct periodic monitoring and submit quarterly reports to the PBT/PBJ.', citation: { source: CITATIONS.CLIP_ON.id, page: 21 } },
                { title: 'Data Submission', details: 'Project data, including the fiber cable route, must be submitted in a softcopy format (e.g., shapefile, KML, AutoCAD) to the Penang GeoHub Portal.', citation: { source: CITATIONS.CLIP_ON.id, page: 21 } },
                { title: 'Permit Fee', details: 'A permit fee of RM500.00 is charged per application.', citation: { source: CITATIONS.CLIP_ON.id, page: 20 } },
                { title: 'Security Deposit (Wang Cagaran)', details: 'A security deposit is required at a rate of RM200.00 per meter, with a minimum charge of RM10,000.00.', citation: { source: CITATIONS.CLIP_ON.id, page: 20 } },
            ]
          }
        ],
    },
    {
        id: 'overhead',
        title: 'Overhead Lines',
        icon: <OverheadIcon />,
        description: 'Guidelines for the installation of overhead lines for the final connection to customer premises, including pole and cable specifications.',
        sections: [
           {
            title: 'Permit Application Flowchart',
            type: 'flowchart',
            description: 'Process for obtaining a permit for overhead line installation projects.',
            citation: { source: CITATIONS.OVERHEAD.id, page: 31 },
            content: [
              { id: 1, title: 'Service Request', responsible: 'Applicant', description: 'Request for service received from user or resident.' },
              { id: 2, title: 'Submit Application', responsible: 'Applicant', description: 'Submit service request proof, development proposal, and supporting documents to PBT/PBJ.' },
              { id: 3, title: 'Receive & Verify Application', responsible: 'Authority', description: 'PBT/PBJ receives and verifies the application for completeness.' },
              { id: 4, title: 'Technical Review', responsible: 'Authority', description: 'Technical review from related departments to prepare the consideration paper for approval.', duration: '33 Days' },
              { id: 5, title: 'Decision and Recommendation', responsible: 'Authority', description: 'Decision and recommendation on the development proposal at the PBT/PBJ level.' },
              { id: 6, title: 'Notify Decision', responsible: 'Authority', description: 'Communicate the decision to the communication company.' },
              { id: 7, title: 'Apply for Permit', responsible: 'Applicant', description: 'Submit a formal permit application to PBT/PBJ.' },
              { id: 8, title: 'Issue Work Start Approval', responsible: 'Authority', description: 'PBT/PBJ issues the Work Start Approval Letter.' },
              { id: 9, title: 'Commence On-Site Work', responsible: 'Applicant', description: 'Project work begins on-site.', duration: '33 Days' },
            ],
          },
          {
            title: 'Application & Legal Framework',
            type: 'info',
            content: [
              { title: 'Governing Policies', details: 'All overhead works are subject to the regulations outlined in the Akta Jalan, Parit Dan Bangunan 1974 (Akta 133) and Akta Pengangkutan Jalan 1987 (Akta 333).', citation: { source: CITATIONS.OVERHEAD.id, page: 7 } },
              { title: 'Required Documents', details: 'A complete application must include: (1) A cover letter, (2) A softcopy of the proposal with AutoCAD files, (3) Three sets of A1 size site plans, (4) Topographical plan, (5) Traffic management plan, (6) Under Ground Mapping (UDM) report if required, (7) Insurance copies, and (8) Letter of Undertaking for cabinet maintenance.', citation: { source: CITATIONS.OVERHEAD.id, page: '27-28' } },
            ]
          },
          {
            title: 'Pole & Cable Specifications',
            type: 'info',
            content: [
                { title: 'Pole Height Application', details: '7.5m poles are used for premise access and low-traffic areas. 9.0m poles are required for road crossings or areas needing higher clearance.', citation: { source: CITATIONS.OVERHEAD.id, page: 11 } },
                { title: 'Pole Spacing', details: 'The recommended distance between poles is 25m to 40m.', citation: { source: CITATIONS.OVERHEAD.id, page: 13 } },
                { title: 'Cable Ground Clearance', details: 'A minimum ground clearance of 4 meters is required for overhead cables.', citation: { source: CITATIONS.OVERHEAD.id, page: 13 } },
                { title: 'Clearance from Power Lines', details: 'A minimum distance of 910mm must be maintained from any power lines.', citation: { source: CITATIONS.OVERHEAD.id, page: 21 } },
                { title: 'Pole Material & Structure', details: 'Spun concrete poles with a minimum of 8 mata (points) are required.', citation: { source: CITATIONS.OVERHEAD.id, page: 15 } },
                { title: 'Pole Design Load', details: 'Poles must meet design load specifications. For a 7.5m pole, the design load is 1.1kN or 2.0kN. For a 9.0m pole, it is 2.0kN.', citation: { source: CITATIONS.OVERHEAD.id, page: 18 } },
                { title: 'Uneven Ground Installation', details: 'For installation on uneven terrain, the maximum height difference between two consecutive poles must not exceed 300mm.', citation: { source: CITATIONS.OVERHEAD.id, page: 18 } },
            ]
          },
           {
            title: 'Pole Installation & Labeling',
            type: 'info',
            content: [
                { title: 'Pole Installation Requirements', details: 'Poles must be installed at a minimum depth of 1500mm. A concrete kicking block is required for support.', citation: { source: CITATIONS.IN_BUILDING.id, page: 40 }, visualization: <PoleInstallationDiagram /> },
                { title: 'Pole Labeling Requirements', details: 'Each utility pole must be clearly marked with: Provider Logo/Name, Asset/ID Number, Contact Phone Number, Pole Length, Design Load, Manufacturing Standard, Manufacturing Date, and Buried Depth Marking.', citation: { source: CITATIONS.OVERHEAD.id, page: 19 } },
            ]
          }
        ]
    },
    {
        id: 'civil-works',
        title: 'Basic Civil Works',
        icon: <CivilWorksIcon />,
        description: 'Procedures for fundamental civil works including Open Trench, Micro Trench, and Horizontal Directional Drilling (HDD).',
        sections: [
            {
                title: 'General Requirements & Materials',
                type: 'info',
                content: [
                  { title: 'Utility Detection Mapping (UDM)', details: 'UDM is mandatory before any excavation to map existing underground utilities. Scanning intervals are tighter (1-3m) in high-risk areas (within 20m of a manhole) and wider (7-10m) in low-risk areas.', citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 18 }, visualization: <UDMScanningDiagram /> },
                  { title: 'Permits & Approvals', details: 'Contractors must obtain a Way Leave from landowners and an External Trenching Permit (ETP) from relevant authorities (e.g., JKR) before work commences.', citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 15 } },
                  { title: 'Traffic Management Plan (TMP)', details: 'A TMP is required for any work affecting roadways. This includes deploying barriers, warning signage, and flagmen to ensure the safety of workers and the public.', citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 22 } },
                  { title: 'Backfilling for Carriageway', details: 'For road crossings, trenches are reinstated with compacted layers of crusher run (250mm) and topped with asphalt premix (50mm). A uPVC warning slab or tape must be laid at a depth of 450-600mm from the ground level.', citation: { source: CITATIONS.CIVIL_OPEN_TRENCH.id, page: 18 }, visualization: <BackfillDiagram /> },
                ]
            },
            {
              title: 'Concrete Quality & Mix Ratios',
              type: 'table',
              description: 'Specifications for concrete quality and mixture ratios for different civil work applications.',
              content: {
                  headers: ['Quality', 'Cement', 'Sand', 'Aggregate', 'Usage'],
                  citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 39 },
                  rows: [
                      ['Quality A', '1', '2', '4', 'Jointing chambers, manhole covers, plinths'],
                      ['Quality B', '1', '3', '6', 'Supporting, protecting, or filling-in purposes'],
                      ['Quality C', '1', '4', '3', 'Encasement of conduits (max 6mm aggregate)'],
                      ['Cement Mortar', '1', '3', '0', 'Plastering, sealing ducts, repairing damage'],
                  ]
              }
            },
            {
                title: 'Open Trench Procedure',
                type: 'steps',
                description: 'Standard procedure for laying underground ducts via the open trench method.',
                citation: { source: CITATIONS.CIVIL_OPEN_TRENCH.id, page: '9-17' },
                content: [
                    {id: 1, title: 'Planning', responsible: 'Shared', description: 'Plan route, get permits, and perform pilot holes to check for underground utilities.'},
                    {id: 2, title: 'Road Cutting & Excavation', responsible: 'Applicant', description: 'Cut asphalt/concrete and excavate trench to required depth (min 1,070mm for 1 layer).'},
                    {id: 3, title: 'Duct Laying', responsible: 'Applicant', description: 'Lay underground ducts (PVC or GI), ensuring proper bedding, alignment, and protection. Use concrete encasement for 4+ ways.'},
                    {id: 4, title: 'Backfilling & Reinstatement', responsible: 'Applicant', description: 'Backfill with sand/soil in layers, compacting each layer. Reinstate surface (grass or asphalt) to original condition.'},
                    {id: 5, title: 'Testing & Completion', responsible: 'Applicant', description: 'Perform mandrel test to ensure duct integrity. Clean up site and complete project handover.'},
                ]
            },
             {
                title: 'Open Trench - Duct Arrangement',
                type: 'info',
                content: [
                    {
                        title: 'Duct Arrangement: Break Joint',
                        details: 'When laying multiple layers of ducts, the joints must be staggered (break joint) by approximately half a duct length. This applies both horizontally and vertically to prevent stress points and maintain structural integrity.',
                        citation: { source: CITATIONS.CIVIL_OPEN_TRENCH.id, page: 12 },
                        visualization: <DuctBreakJointDiagram />
                    },
                ]
            },
            {
                title: 'Micro Trench Procedure & Specifications',
                type: 'info',
                citation: { source: CITATIONS.CIVIL_MICRO_TRENCH.id, page: '4-6' },
                content: [
                    {
                        title: 'Trenching Dimensions & Layers',
                        details: 'Micro trenching involves a narrow 300mm deep x 50mm wide groove. It is filled with a 20mm sand bedding, the microduct, a 60mm sand topping, then reinstated with red mortar and asphalt.',
                        citation: { source: CITATIONS.CIVIL_MICRO_TRENCH.id, page: 8 },
                        visualization: <MicroTrenchDiagram />
                    },
                ]
            },
            {
                title: 'Horizontal Directional Drilling (HDD) Procedure & Specifications',
                type: 'info',
                citation: { source: CITATIONS.CIVIL_HDD.id, page: '5' },
                content: [
                    {
                        title: 'Drilling Parameters',
                        details: 'HDD involves drilling a pilot hole with an entry/exit angle between 10° and 18°. The minimum depth below a finished road surface must be 3.0 meters.',
                        citation: { source: CITATIONS.CIVIL_HDD.id, page: 8 },
                        visualization: <HDDDiagram />
                    },
                    {
                        title: 'Reaming and Pipe Pulling',
                        details: 'After the pilot hole is drilled, the bore is enlarged by a reamer. The HDPE duct is then pulled back through the enlarged hole.',
                        citation: { source: CITATIONS.CIVIL_HDD.id, page: 14 }
                    },
                    {
                        title: 'Machine Requirements',
                        details: 'Machine size and thrust/pullback force depend on the distance. For short ranges (<100m), a machine with <2000kg weight and 20-22 kN force is used. For long ranges (>500m), machines >8000kg with >100 kN force are required.',
                        citation: { source: CITATIONS.CIVIL_HDD.id, page: 10 }
                    }
                ]
            },
        ]
    },
    {
        id: 'in-building',
        title: 'In-Building & External',
        icon: <InBuildingIcon />,
        description: 'Requirements for in-building and external fixed network facilities for SDU, MDU, and campus-type developments.',
        sections: [
          {
            title: 'Infrastructure Development Workflow',
            type: 'steps',
            description: 'Key stages from planning to handover for deploying network infrastructure in new developments.',
            citation: { source: CITATIONS.IN_BUILDING.id, page: '13-14' },
            content: [
              {id: 1, title: 'Phase 1: Planning & Design', responsible: 'Shared', description: 'Developer consults with NFP to plan infrastructure (TR, risers, manholes, duct routes) within the Private Property Line (PPL).'},
              {id: 2, title: 'Phase 2: Construction', responsible: 'Applicant', description: 'Developer builds all required external (manholes, ducts) and in-building (TR, risers, trunking) infrastructure.'},
              {id: 3, title: 'Phase 3: Cabling Installation', responsible: 'Applicant', description: 'Developer installs all internal cabling from the FTB (in TR or riser) to the FWS in each individual unit.'},
              {id: 4, title: 'Phase 4: Acceptance & Handover', responsible: 'Shared', description: 'Developer requests infrastructure and cabling acceptance from NFP. Upon successful testing and verification, NFP issues a Certificate of Acceptance (COA). Infrastructure ownership is transferred to the property owner (JMB/MC).'},
              {id: 5, title: 'Phase 5: Service Activation', responsible: 'Authority', description: 'NFP connects its network to the building\'s FTB and installs equipment in the TR. NFP then connects and activates services for individual subscribers.'},
            ]
          },
          {
            title: 'Key Infrastructure Requirements',
            type: 'info',
            content: [
                { title: 'Telecommunication Room (TR)', details: 'A dedicated, secure room for network equipment. Must have adequate space (min 750mm clearance), power (with backup), proper earthing (≤ 10 Ω), and climate control (Temp < 30°C, Humidity 30-50%).', citation: { source: CITATIONS.IN_BUILDING.id, page: 16 } },
                { title: 'Riser & Trunking', details: 'Vertical risers and horizontal trunking must be used exclusively for telecommunication services and kept separate from other utilities like water or gas. Trunking must have a bending radius greater than 10 times its size.', citation: { source: CITATIONS.IN_BUILDING.id, page: 21 } },
                { title: 'Fibre Termination Box (FTB)', details: 'The connection point between external and in-building fibre. For MDUs, it is located in the TR. For landed SDUs, it is installed on the outside wall of the premises.', citation: { source: CITATIONS.IN_BUILDING.id, page: 23 } },
                { title: 'Fibre Wall Socket (FWS)', details: 'The termination point for internal fibre cable inside the customer\'s premises. It must be located 300mm above the floor and support a minimum of 2 fibre cores.', citation: { source: CITATIONS.IN_BUILDING.id, page: 26 } },
                { title: 'Customer Premises Equipment (CPE) Outlet', details: 'Registered Jacket type 45 (RJ45) outlet socket for internet-based CPE (CAT5e or higher). Registered Jacket type 11 (RJ11) outlet socket for analogue telephone (CAT3 or higher).', citation: { source: CITATIONS.IN_BUILDING.id, page: 27 } },
                { title: 'Internal Fiber Cable', details: 'Must be single-mode type and comply with ITU-T G.657.A1 (bend-insensitive). The sheath shall be Low Smoke Zero Halogen (LSZH).', citation: { source: CITATIONS.IN_BUILDING.id, page: 58 } },
            ]
          },
          {
            title: 'Survey, Design, & Submission Requirements',
            type: 'info',
            description: 'End-to-end documentation and design obligations for developers, from planning to final project handover and NFP acceptance.',
            content: [
                { title: 'Early Consultation & Planning', details: 'Developers must engage with the selected NFP at least 90 working days before infrastructure connection to ensure all requirements for TR, risers, ducts, and manholes are met.', citation: { source: CITATIONS.IN_BUILDING.id, page: 61 } },
                { title: 'Design & Cabling Plan', details: 'A comprehensive design must be provided, including schematic diagrams, fibre core assignment plans, and specifications for cable types and core counts (min. 2 for residential, 4 for business).', citation: { source: CITATIONS.IN_BUILDING.id, page: 42 } },
                { title: 'Final Submission for Acceptance', details: 'For project acceptance, a complete package must be submitted to the NFP, including: an endorsed NFP acceptance checklist, as-built drawings, schematic diagrams, fibre core assignments, full cabling test results (e.g., OTDR), and test equipment calibration certificates.', citation: { source: CITATIONS.IN_BUILDING.id, page: 63 } },
            ]
          }
        ]
    },
];

// DEDICATED TESTS DATA
export const TESTS_DATA: WorkflowCategory = {
    id: 'types-of-test',
    title: 'Types of Test',
    icon: <TestIcon />,
    description: 'A comprehensive guide to the testing methods and acceptance criteria required for telecommunications civil works, including physical duct tests and optical fiber tests.',
    sections: [
        {
            title: 'Pre-Work & Tracking Tests',
            type: 'info',
            content: [
                 {
                    title: 'Ground Penetrating Radar (GPR) Scan',
                    description: 'A pre-excavation scan to map existing underground utilities.',
                    details: '',
                    citation: { source: CITATIONS.CIVIL_GENERAL.id, page: '16-17' },
                    subItems: [
                        {
                            title: 'Purpose',
                            details: 'To detect and locate any buried utilities (metal or non-metal) like pipes or other cables before excavation begins, in order to prevent costly and dangerous damage.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 16 },
                        },
                        {
                            title: 'Method',
                            details: 'A GPR device is moved across the proposed route. It sends radar pulses into the ground and detects reflected signals from buried objects to create a subsurface map.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 18 },
                        },
                        {
                            title: 'Output',
                            details: 'A Utility Detection Mapping (UDM) report that includes the location, depth, and type of all detected underground utilities along the proposed route.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 17 },
                        }
                    ]
                },
                {
                    title: 'Sonde (Walk-over Tracking System)',
                    description: 'A real-time tracking method used during Horizontal Directional Drilling (HDD).',
                    details: '',
                    citation: { source: CITATIONS.CIVIL_HDD.id, page: 13 },
                    subItems: [
                        {
                            title: 'Purpose',
                            details: 'To determine the depth, location, and direction of the HDD bore head in real-time, ensuring it follows the planned path and avoids obstacles.',
                            citation: { source: CITATIONS.CIVIL_HDD.id, page: 13 },
                        },
                        {
                            title: 'Method',
                            details: 'A transmitter (sonde) is installed inside the bore head. It emits an electromagnetic signal that is detected by a receiver held by an operator walking over the drill path on the surface.',
                            citation: { source: CITATIONS.CIVIL_HDD.id, page: 13 },
                        },
                        {
                            title: 'Acceptance Criteria',
                            details: 'The contractor must monitor and record the horizontal and vertical alignment of the pilot bore at intervals of no more than 6m to 9m to ensure it complies with the specified drill path.',
                            citation: { source: CITATIONS.CIVIL_HDD.id, page: 13 },
                        }
                    ]
                },
            ]
        },
        {
            title: 'Physical Duct Integrity Tests',
            type: 'info',
            content: [
                {
                    title: 'Mandrel Test',
                    description: 'A test to ensure the duct is clear of obstructions and its circular shape is maintained after installation.',
                    details: '',
                    citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 35 },
                     subItems: [
                        {
                            title: 'Purpose',
                            details: 'To verify that the duct is not crushed, bent, or blocked by debris, ensuring that fiber optic cable can be pulled or blown through it without damage.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 35 }
                        },
                        {
                            title: 'Method',
                            details: 'A cylindrical brush followed by a mandrel of a specific diameter (e.g., 83mm for a 100mm duct) is pulled through the entire duct length twice, once from each direction. The mandrel should pass through smoothly without getting stuck.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 44 }
                        },
                        {
                            title: 'Pass Criteria',
                            details: 'The mandrel must travel from one end of the duct to the other without obstruction. If any defect is discovered, it must be rectified immediately.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 44 }
                        }
                    ]
                },
                {
                    title: 'Blowing Test (for HDPE Ducts)',
                    description: 'A test performed on HDPE ducts intended for cable blowing to ensure duct integrity and airtightness.',
                    details: '',
                    citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 45 },
                    subItems: [
                        {
                            title: 'Purpose',
                            details: 'To confirm that the duct and its joints can hold pressure and that a carrier (parachute) can travel through it smoothly, which is essential for the blowing installation method.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 45 }
                        },
                        {
                            title: 'Method',
                            details: 'The duct is pressurized to check for air loss. A short fiber cable attached to a carrier or parachute is then inserted into the duct via a cable blower. High-pressure air is injected to propel the carrier through the duct.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 45 }
                        },
                        {
                            title: 'Pass Criteria',
                            details: 'The test is successful when the carrier or parachute successfully reaches the other end of the duct line.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 45 }
                        }
                    ]
                }
            ]
        },
        {
            title: 'Road Reinstatement Tests',
            type: 'info',
            content: [
                {
                    title: 'Road Coring Test',
                    description: 'A test performed after road reinstatement to verify the thickness and quality of the newly laid asphalt.',
                    details: '',
                    citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 46 },
                    subItems: [
                         {
                            title: 'Purpose',
                            details: 'To ensure the road surface has been restored to the required specifications (e.g., minimum 50mm asphalt premix thickness) to prevent premature failure or sinking.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 46 }
                        },
                        {
                            title: 'Method',
                            details: 'A cylindrical core sample is drilled from the reinstated paved surface. The thickness of the asphalt and underlying layers is then measured. Sampling rate is typically one sample per 500 m² of premix laid.',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 46 }
                        },
                        {
                            title: 'Pass Criteria',
                            details: 'The core sample must meet the thickness specifications set by the relevant authority (e.g., JKR/SPJ/2008).',
                            citation: { source: CITATIONS.CIVIL_GENERAL.id, page: 46 }
                        }
                    ]
                }
            ]
        },
        {
            title: 'Optical Fiber Performance Tests',
            type: 'info',
            content: [
                {
                    title: 'Optical Time Domain Reflectometer (OTDR) Test',
                    description: 'A single-ended test that provides a graphical trace of the fiber link, showing insertion loss, event loss (splices/connectors), distance, and ORL.',
                    details: '',
                    citation: { source: CITATIONS.IN_BUILDING.id, page: 65 },
                    subItems: [
                         {
                            title: 'Purpose',
                            details: 'To characterize the fiber link, identify faults, measure splice/connector quality, and verify the overall integrity and length of the cable.',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 65 }
                        },
                        {
                            title: 'Method',
                            details: 'A launch fiber (dummy fiber) of sufficient length (min. 10m, 100m recommended) is connected between the OTDR and the link. A tail fiber is used at the far end to measure the last connector. A bi-directional test is performed for full characterization.',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 65 }
                        },
                    ]
                },
                 {
                    title: 'Optical Loss Test Set (OLTS) / Power Meter & Light Source',
                    description: 'Measures the total attenuation (insertion loss) of a fiber link from end-to-end.',
                    details: '',
                    citation: { source: CITATIONS.IN_BUILDING.id, page: 65 },
                     subItems: [
                        {
                            title: 'Purpose',
                            details: 'To provide a simple pass/fail result based on the total light lost over the entire cable link compared to the pre-calculated link loss budget.',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 65 }
                        },
                        {
                            title: 'Method',
                            details: 'A light source is placed at one end of the link and a power meter at the other. A reference is set using a high-quality test patch cord. The measurement is taken and then the equipment is swapped to perform a bi-directional test.',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 66 }
                        },
                    ]
                },
                {
                    title: 'Testing Wavelengths & Purpose',
                    description: 'Optical fiber tests are performed at two primary wavelengths to ensure a comprehensive assessment of the cable\'s performance and integrity.',
                    details: '',
                    citation: { source: CITATIONS.IN_BUILDING.id, page: 58 },
                    subItems: [
                        {
                            title: '1310 nm (Primary)',
                            details: 'This is the standard wavelength for loss measurements. It is highly sensitive to physical stress on the fiber, such as sharp bends (macrobends), making it excellent for detecting installation-related faults.',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 77 },
                        },
                        {
                            title: '1550 nm (Secondary)',
                            details: 'This wavelength is more sensitive to microbends, which are small-scale imperfections in the fiber that can occur during manufacturing or from cable stress over time. Testing at 1550nm helps identify potential long-term degradation issues.',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 77 },
                        },
                    ]
                },
                 {
                    title: 'Component Pass Criteria (OTDR Analysis)',
                    description: 'Maximum acceptable values for individual events measured by an OTDR. Exceeding these values indicates a fault that must be rectified.',
                    details: '',
                    citation: { source: CITATIONS.IN_BUILDING.id, page: 47 },
                    subItems: [
                        {
                            title: 'Splice Loss',
                            details: 'A fusion splice should not exceed **0.1 dB** of loss.',
                        },
                        {
                            title: 'Connector Loss',
                            details: 'A mated connector pair should not exceed **0.5 dB** of loss.',
                        },
                        {
                            title: 'Reflectance (UPC)',
                            details: 'For UPC (Ultra Physical Contact) connectors, reflectance should be **≤ -50 dB**.',
                        },
                        {
                            title: 'Reflectance (APC)',
                            details: 'For APC (Angled Physical Contact) connectors, reflectance should be **≤ -60 dB**. The angled polish significantly reduces reflectance, making APC superior for high-speed data and video.',
                        },
                         {
                            title: 'Span ORL',
                            details: 'The Optical Return Loss for the total span should be **> 20 dB**.',
                        },
                    ]
                },
                {
                    title: 'Total Link Pass Criteria: Maximum Attenuation Loss',
                    description: 'The total end-to-end insertion loss must not exceed the maximum allowable limits for the specific cable segment.',
                    details: '',
                    subItems: [
                         {
                            title: 'In-Building / Last Mile Links',
                            details: 'The total bi-directional end-to-end insertion loss, measured at 1310 nm, must not exceed these limits:\n\n• SDU (Served via Pole): **1.6 dB**\n• SDU (Served via Underground): **2.3 dB**\n• MDU (Single Building): **2.3 dB**',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 65 }
                        },
                        {
                            title: 'OSP/ODN Links (Landed Strata)',
                            details: 'The total bi-directional end-to-end insertion loss, measured at 1310 nm, must not exceed this limit:\n\n• Strata Development Area (FTB in FDH to FWS): **1.46 dB** (for links up to 1 km)',
                            citation: { source: CITATIONS.IN_BUILDING.id, page: 50 }
                        }
                    ]
                },
            ]
        },
    ]
};
