export const CITATIONS = {
  CLIP_ON: {
    id: 'CLIP_ON',
    apa: 'Kerajaan Negeri Pulau Pinang. (2021). Garis Panduan Pemasangan Kabel Fiber Clip On Solution Di Negeri Pulau Pinang.',
    url: 'https://www.penang.gov.my/images/koleksi/dasar/Garis_Panduan_Pemasangan_Kabel_Fiber_Clip_On_Solution_Di_Negeri_Pulau_Pinang.pdf'
  },
  OVERHEAD: {
    id: 'OVERHEAD',
    apa: 'Kerajaan Negeri Pulau Pinang. (2024). Garis Panduan Pemasangan Talian Atas Untuk Sambungan Akhir Ke Premis Pelanggan Di Negeri Pulau Pinang.',
    url: 'https://www.penang.gov.my/images/koleksi/dasar/LAMPIRAN_A_-_GARIS_PANDUAN_PEMASANGAN_TALIAN_ATAS_UNTUK_SAMBUNGAN_AKHIR_KE_PREMIS_PELANGGAN_DI_NEGERI_PULAU_PINANG_TAHUN_2024.pdf'
  },
  CIVIL_GENERAL: {
    id: 'CIVIL_GENERAL',
    apa: 'MCMC MTSFB. (2020). Basic Civil Works - Part 1: General Requirements (TC G025-1:2020).',
    url: 'https://www.mcmc.gov.my/skmmgovmy/media/General/MCMC-MTSFB-TC-G025-1_2020-BASIC-CIVIL-WORKS-PART-1-GENERAL-REQUIREMENTS.pdf'
  },
  CIVIL_OPEN_TRENCH: {
    id: 'CIVIL_OPEN_TRENCH',
    apa: 'MCMC MTSFB. (2020). Basic Civil Works - Part 2: Open Trench (TC G025-2:2020).',
    url: 'https://www.mcmc.gov.my/skmmgovmy/media/General/MCMC-MTSFB-TC-G025-2_2020-BASIC-CIVIL-WORKS-PART-2-OPEN-TRENCH.pdf'
  },
  CIVIL_MICRO_TRENCH: {
    id: 'CIVIL_MICRO_TRENCH',
    apa: 'MCMC MTSFB. (2020). Basic Civil Works - Part 3: Micro Trench (TC G025-3:2020).',
    url: 'https://www.mcmc.gov.my/skmmgovmy/media/General/MCMC-MTSFB-TC-G025-3_2020-BASIC-CIVIL-WORKS-PART-3-MICRO-TRENCH.pdf'
  },
  CIVIL_HDD: {
    id: 'CIVIL_HDD',
    apa: 'MCMC MTSFB. (2020). Basic Civil Works - Part 4: Horizontal Directional Drilling (TC G025-4:2020).',
    url: 'https://www.mcmc.gov.my/skmmgovmy/media/General/MCMC-MTSFB-TC-G025-4_2020-BASIC-CIVIL-WORKS-PART-4-HORIZONTAL-DIRECTIONAL-DRILLING.pdf'
  },
  IN_BUILDING: {
    id: 'IN_BUILDING',
    apa: 'MCMC MTSFB. (2024). Fixed Network Facilities - In-building and External (First Revision) (TC G024:2024).',
    url: 'https://www.mcmc.gov.my/skmmgovmy/media/General/MCMC-MTSFB-TC-G024_2024-FIXED-NETWORK-FACILITIES-IN-BUILDING-AND-EXTERNAL-(FIRST-REVISION).pdf'
  },
};