
import React, { useState } from 'react';
import { WorkflowCategory } from '../types';
import { DocumentIcon, WorkflowIcon, TestIcon, ChevronDownIcon, FTTXIcon } from './Icons';

type ActiveView = 'WORKFLOWS' | 'TESTS' | 'DOCUMENTS';

interface SidebarProps {
  workflows: WorkflowCategory[];
  tests: WorkflowCategory;
  activeView: ActiveView;
  onActiveViewChange: (view: ActiveView) => void;
  selectedWorkflowId: string;
  onSelectWorkflow: (id: string) => void;
}

export default function Sidebar({ 
    workflows, 
    tests, 
    activeView, 
    onActiveViewChange, 
    selectedWorkflowId, 
    onSelectWorkflow 
}: SidebarProps) {
  const [isWorkflowsOpen, setIsWorkflowsOpen] = useState(true);

  const mainNavItems = [
    { id: 'WORKFLOWS', label: 'Workflows', icon: <WorkflowIcon /> },
    { id: 'TESTS', label: tests.title, icon: tests.icon },
    { id: 'DOCUMENTS', label: 'Source Documents', icon: <DocumentIcon /> },
  ];

  return (
    <aside className="w-72 bg-gray-800 text-white flex-shrink-0 p-4 flex flex-col">
      <div className="flex items-center mb-8 px-2">
         <div className="text-indigo-400 w-8 h-8">
            <FTTXIcon />
         </div>
        <h1 className="text-xl font-bold ml-2">FTTX Civil Guideline</h1>
      </div>
      
      <nav className="flex-1 overflow-y-auto pb-4">
        {mainNavItems.map(item => (
            <div key={item.id}>
                 <button
                    onClick={() => {
                        onActiveViewChange(item.id as ActiveView);
                        if (item.id === 'WORKFLOWS') {
                            setIsWorkflowsOpen(prev => !prev);
                        }
                    }}
                    className={`w-full flex items-center p-3 rounded-lg text-left transition-colors duration-200 text-base font-semibold ${
                      activeView === item.id
                        ? 'bg-indigo-600 text-white'
                        : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                    }`}
                >
                    <span className="w-6 h-6 mr-3">{item.icon}</span>
                    <span>{item.label}</span>
                    {item.id === 'WORKFLOWS' && (
                        <span className={`ml-auto transform transition-transform duration-200 ${isWorkflowsOpen ? 'rotate-180' : ''}`}>
                            <ChevronDownIcon />
                        </span>
                    )}
                </button>
                {item.id === 'WORKFLOWS' && isWorkflowsOpen && (
                     <ul className="pl-6 py-2">
                        {workflows.map(workflow => (
                            <li key={workflow.id} className="mb-1">
                            <button
                                onClick={() => {
                                    onActiveViewChange('WORKFLOWS');
                                    onSelectWorkflow(workflow.id);
                                }}
                                className={`w-full flex items-center py-2 px-3 rounded-md text-left transition-colors duration-200 text-sm ${
                                selectedWorkflowId === workflow.id && activeView === 'WORKFLOWS'
                                    ? 'bg-gray-700 text-white font-semibold'
                                    : 'text-gray-400 hover:bg-gray-700 hover:text-white'
                                }`}
                            >
                                <span className="w-5 h-5 mr-3 flex-shrink-0">{workflow.icon}</span>
                                <span>{workflow.title}</span>
                            </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        ))}
      </nav>
      
      <div className="text-xs text-gray-500 mt-4 pt-4 border-t border-gray-700 px-2">
        <p>&copy; 2024 Workflow Guide</p>
        <p>Based on MCMC & Penang State Guidelines</p>
      </div>
    </aside>
  );
}