import React from 'react';

export function HDDDiagram() {
  return (
    <div className="w-full bg-gray-50 p-4 rounded-lg border border-gray-200 text-xs sm:text-sm">
      <div className="flex justify-between items-end mb-1">
        <div className="text-center">
          <div className="font-bold">Starting Hole</div>
          <div className="h-10 w-16 bg-gray-300 border border-gray-400 mt-1"></div>
        </div>
        <div className="text-center font-semibold text-green-800 -mb-2 px-2 bg-gray-50 z-10">Ground Level</div>
        <div className="text-center">
          <div className="font-bold">Receiving Hole</div>
          <div className="h-10 w-16 bg-gray-300 border border-gray-400 mt-1"></div>
        </div>
      </div>
      <div className="relative h-40 w-full border-t-2 border-dashed border-green-700 bg-yellow-100">
        {/* Drill path */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 100" preserveAspectRatio="none">
          <path d="M 10 10 C 50 80, 250 80, 290 10" stroke="#f59e0b" strokeWidth="2.5" fill="none" />
        </svg>
        {/* Setback left */}
        <div className="absolute top-0 left-1/4 -translate-x-1/2">
          <div className="text-center">Setback</div>
          <div className="text-center font-bold">10-16m</div>
          <div className="h-2 border-l border-gray-500 absolute left-0 top-full"></div>
          <div className="h-2 border-l border-gray-500 absolute right-0 top-full"></div>
        </div>
         {/* Setback right */}
        <div className="absolute top-0 right-1/4 -translate-x-1/2">
          <div className="text-center">Setback</div>
          <div className="text-center font-bold">10-16m</div>
          <div className="h-2 border-l border-gray-500 absolute left-0 top-full"></div>
          <div className="h-2 border-l border-gray-500 absolute right-0 top-full"></div>
        </div>
         {/* Depth */}
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 flex items-center">
           <div className="h-12 w-px bg-red-500"></div>
           <div className="ml-2 text-red-600 font-bold">Depth: min 3.0m</div>
         </div>
         {/* Entry Angle */}
         <div className="absolute top-1 left-2 text-indigo-600 font-semibold">Entry: 10°-18°</div>
         {/* Exit Angle */}
         <div className="absolute top-1 right-2 text-indigo-600 font-semibold">Exit: 10°-18°</div>
      </div>
    </div>
  );
}