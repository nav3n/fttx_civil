
import React from 'react';

const Layer = ({ height, color, label, depth, children }: { height: string, color: string, label: string, depth?: string, children?: React.ReactNode }) => (
    <div style={{ height }} className={`relative w-full ${color} flex items-center justify-center border-b border-gray-500`}>
        <div className="absolute left-2 right-2 flex justify-between items-center text-white text-xs sm:text-sm font-bold">
             <span className="bg-black bg-opacity-60 px-2 py-1 rounded">{label}</span>
             {depth && <span className="bg-black bg-opacity-60 px-2 py-1 rounded">{depth}</span>}
        </div>
        {children}
    </div>
);

export const MicroTrenchDiagram = () => {
    return (
        <div className="w-full max-w-xs mx-auto my-4 flex">
            {/* Dimension Line Left */}
            <div className="flex flex-col items-center w-8 text-xs font-semibold text-gray-600">
                <div className="w-px h-full bg-gray-500 relative">
                     <div className="absolute top-1/2 -left-8 -translate-y-1/2 transform -rotate-90">300mm</div>
                     <div className="absolute -top-px left-0 w-4 h-px bg-gray-500"></div>
                     <div className="absolute -bottom-px left-0 w-4 h-px bg-gray-500"></div>
                </div>
            </div>
            
            {/* Trench Cross-section */}
            <div className="w-40 border-2 border-yellow-800 bg-yellow-300">
                <div className="h-96 w-full flex flex-col">
                    <Layer height="50%" color="bg-gray-800" label="Asphalt" />
                    <Layer height="10%" color="bg-red-900" label="Red Mortar" />
                    <Layer height="20%" color="bg-yellow-500" label="Sand" depth="60mm" />
                    <Layer height="20%" color="bg-yellow-300" label="Sand" depth="20mm">
                        <div className="w-6 h-6 rounded-full bg-blue-500 border-2 border-blue-800 flex items-center justify-center text-white text-[8px] font-bold">Duct</div>
                    </Layer>
                </div>
                 {/* Dimension Line Bottom */}
                <div className="flex justify-center items-center h-8 text-xs font-semibold text-gray-600">
                    <div className="h-px w-full bg-gray-500 relative">
                        <div className="absolute left-1/2 -bottom-5 -translate-x-1/2">50mm</div>
                        <div className="absolute top-0 -left-px w-px h-4 bg-gray-500"></div>
                        <div className="absolute top-0 -right-px w-px h-4 bg-gray-500"></div>
                    </div>
                </div>
            </div>
        </div>
    );
};
