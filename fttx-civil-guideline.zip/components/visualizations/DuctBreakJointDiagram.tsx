import React from 'react';

const Duct = () => <div className="w-16 h-8 rounded-full bg-gray-500 border-2 border-gray-700 flex items-center justify-center text-white text-xs font-semibold">DUCT</div>;

const ConcreteLayer = ({ children }: { children: React.ReactNode }) => (
    <div className="relative w-full bg-gray-300 border-b-2 border-dashed border-gray-500 py-2 flex justify-center items-center">
        {children}
        <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-600">SAND/CONCRETE 50mm</span>
    </div>
);

export const DuctBreakJointDiagram = () => (
    <div className="w-full max-w-md mx-auto my-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <div className="relative w-full">
            <div className="text-center font-bold text-green-800 mb-2">GROUND LEVEL</div>
            <div className="h-2 w-full bg-green-200 border-t-2 border-b-2 border-green-700 mb-4"></div>
            
            <div className="space-y-2">
                <ConcreteLayer>
                    <div className="flex space-x-8">
                        <Duct />
                        <Duct />
                    </div>
                </ConcreteLayer>
                <ConcreteLayer>
                     <div className="flex space-x-8">
                        <Duct />
                        <Duct />
                        <Duct />
                    </div>
                </ConcreteLayer>
            </div>

            {/* Break Joint Arrow */}
            <div className="absolute top-1/2 left-12 mt-4">
                 <svg width="110" height="40" viewBox="0 0 110 40" className="overflow-visible">
                    <path d="M 0 20 Q 55 0, 110 20" stroke="red" strokeWidth="2" fill="none" strokeDasharray="4 4"/>
                    <path d="M 55 20 v 20" stroke="red" strokeWidth="2" fill="none" />
                    <text x="55" y="15" textAnchor="middle" fill="red" fontSize="12" fontWeight="bold">X ≈ 3m</text>
                 </svg>
            </div>
        </div>
    </div>
);