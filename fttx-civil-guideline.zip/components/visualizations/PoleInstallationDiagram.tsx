import React from 'react';

export function PoleInstallationDiagram() {
  return (
    <div className="w-full max-w-xs mx-auto my-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
      <div className="relative h-96 flex justify-center">
        {/* Pole */}
        <div className="w-8 bg-gray-500 rounded-t-sm z-10 absolute bottom-[33.33%] h-2/3"></div>
        <div className="w-10 bg-gray-400 rounded-t-sm z-0 absolute bottom-[33.33%] h-2/3 transform translate-x-px"></div>

        {/* Ground */}
        <div className="absolute bottom-0 h-1/3 w-full bg-green-100 border-t-2 border-dashed border-green-700">
            <span className="absolute top-1 left-2 text-xs font-semibold text-green-800">Ground Level</span>
        </div>

        {/* Depth Measurement */}
        <div className="absolute bottom-0 h-1/3 w-px bg-red-500 left-8">
          <div className="absolute -left-20 top-1/2 -translate-y-1/2 text-red-600 text-sm font-semibold">1500mm depth</div>
          <div className="absolute left-0 -top-px w-4 h-px bg-red-500"></div>
          <div className="absolute left-0 -bottom-px w-4 h-px bg-red-500"></div>
        </div>
        
        {/* Concrete Block */}
        <div className="absolute bottom-0 w-24 h-16 bg-gray-300 border border-gray-400 flex items-center justify-center text-xs text-center text-gray-700 p-1">
          Concrete Kicking Block
        </div>
      </div>
    </div>
  );
}