import React from 'react';

const Manhole = ({ label }: { label: string }) => (
  <div className="w-16 h-8 bg-gray-700 text-white flex items-center justify-center font-bold text-sm rounded border-2 border-black">{label}</div>
);

const Zone = ({ width, label, interval, color }: { width: string, label: string, interval: string, color: string }) => (
  <div className={`h-full ${color} flex flex-col items-center justify-center text-white p-2`} style={{ width }}>
    <span className="font-bold text-sm">{label}</span>
    <span className="text-xs">{interval}</span>
  </div>
);

export const UDMScanningDiagram = () => (
  <div className="w-full max-w-lg mx-auto my-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
    <div className="relative flex items-center justify-between w-full h-24 bg-gray-200 border-y-2 border-gray-400">
      <Manhole label="MH 1" />
      <div className="absolute inset-0 flex">
        <Zone width="30%" label="High Risk Zone" interval="Scan 1-3m" color="bg-red-500 bg-opacity-70" />
        <Zone width="40%" label="Low Risk Zone" interval="Scan 7-10m" color="bg-green-500 bg-opacity-70" />
        <Zone width="30%" label="High Risk Zone" interval="Scan 1-3m" color="bg-red-500 bg-opacity-70" />
      </div>
      <Manhole label="MH 2" />
    </div>
     <div className="relative flex w-full h-8 px-10">
        <div className="w-[30%] border-r-2 border-gray-400 h-full relative">
            <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-xs font-semibold">20m</span>
        </div>
        <div className="w-[40%] border-r-2 border-gray-400 h-full"></div>
        <div className="w-[30%] h-full relative">
            <span className="absolute -bottom-5 right-1/2 translate-x-1/2 text-xs font-semibold">20m</span>
        </div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 h-full border-l-2 border-gray-400"></div>
    </div>
  </div>
);