import React from 'react';

// A robust layer component using flexbox to prevent label overlap
function DiagramLayer({ flexBasis, color, label, depth }: { flexBasis: string; color: string; label: string; depth?: string }) {
  return (
    <div style={{ flexBasis }} className={`${color} w-full flex items-center justify-between px-2 text-white font-bold relative border-b border-gray-600`}>
      <span className="bg-black bg-opacity-50 px-2 py-1 rounded text-xs sm:text-sm">{label}</span>
      {depth && (
        <span className="bg-black bg-opacity-50 px-2 py-1 rounded text-xs sm:text-sm">{depth}</span>
      )}
    </div>
  );
}

export function BackfillDiagram() {
  return (
    // Using aspect ratio to make the diagram's proportions dynamic and responsive
    <div className="w-full max-w-xs mx-auto my-4 border-4 border-yellow-800 bg-yellow-300 p-2">
      <div className="bg-white w-full aspect-[9/16] flex flex-col">
        {/* Layer heights are now proportional using flex-basis */}
        <DiagramLayer flexBasis="15%" color="bg-gray-800" label="Asphalt Premix" depth="50mm" />
        <DiagramLayer flexBasis="25%" color="bg-gray-600" label="Crusher Run" depth="250mm" />
        <DiagramLayer flexBasis="10%" color="bg-yellow-500" label="Warning Tape" />
        <div className="flex-grow bg-yellow-200 relative pt-4 flex flex-col justify-end pb-2">
            <div className="w-full flex justify-center space-x-2 mb-2">
                <div className="w-10 h-10 rounded-full bg-gray-500 border-2 border-gray-700 flex items-center justify-center text-xs text-white font-semibold">Duct</div>
                <div className="w-10 h-10 rounded-full bg-gray-500 border-2 border-gray-700 flex items-center justify-center text-xs text-white font-semibold">Duct</div>
            </div>
            <div className="w-full text-center text-gray-700 text-xs font-semibold">Sand Bedding (50mm)</div>
        </div>
      </div>
    </div>
  );
}